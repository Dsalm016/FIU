/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * Student ID: 6312209 
 * Section: COP3804 
 * Due date: 03/23/22
 */
// Student ID: 6312209
// Section: COP3804
// Due date: 03/23/22
public class Recursion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // create instance of this class and call instance method
        Recursion r = new Recursion();
        System.out.println("Change 'x' to 'y' with recursion");

        // criterion 3: print statements that make use of recursive method
        // criterion 5: correct results are provided
        System.out.println("codex -> " + r.changeXY("codex"));
        System.out.println("xxhixx -> " + r.changeXY("xxhixx"));
        System.out.println("xhixhix -> " + r.changeXY("xhixhix"));
    }

    // criterion 1: changeXY method with signature 
    // public String changeXY(String str)
    public String changeXY(String str) {
        // criterion 2: base case
        // we select base case to be empty string
        // because there may still be transformations for 1-character strings
        if (str.length() == 0) {
            return str;
        }

        // our recursion works as follows:
        // changeXY(s) = change first character from x to y if necessary + changeXY(rest of string s)
        // change first character from x to y if necessary
        char newFirstChar = str.charAt(0);
        if (newFirstChar == 'x') {
            newFirstChar = 'y';
        }

        // return the result: first transformed character + changeXY(rest of string)
        // criterion 4: simplifying call (with shorter string)
        return newFirstChar + changeXY(str.substring(1));
    }

}
